-- PostgreSQL 16 + PostGIS 3. Run as superuser once. Roles use client-cert auth (pg_hba: hostssl all yl_* all cert).
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE source_type AS ENUM ('OFFICIAL_GOVT','OPERATOR_DIRECT','OSM_OVERPASS','VERIFIED_USER_OBSERVATION');
CREATE TYPE claim_type  AS ENUM ('OPERATING_HOURS','CLOSURE','ENTRY_RESTRICTION','TRANSPORT_FARE','ACCESSIBILITY');
CREATE TYPE claim_state AS ENUM ('PENDING','ACCEPTED','REJECTED','QUARANTINED');

CREATE TABLE places (
  place_id text PRIMARY KEY CHECK (place_id ~ '^[a-z0-9_]{3,64}$'),
  name text NOT NULL CHECK (length(name) BETWEEN 1 AND 160),
  category text NOT NULL CHECK (category IN ('major_landmark','craft_artisan','minor_heritage','local_eatery','essential_service')),
  geog geography(Point,4326) NOT NULL,
  visit_minutes int NOT NULL CHECK (visit_minutes BETWEEN 0 AND 240),
  sensitive boolean NOT NULL DEFAULT false
);
CREATE INDEX places_geog_gix ON places USING gist (geog);

CREATE TABLE services (
  service_id bigserial PRIMARY KEY,
  kind text NOT NULL CHECK (kind IN ('PHARMACY','BUDGET_FOOD','AUTO_STAND')),
  geog geography(Point,4326) NOT NULL,
  open_late boolean NOT NULL DEFAULT false
);
CREATE INDEX services_geog_gix ON services USING gist (geog);

CREATE TABLE travel_time (   -- filled offline from an OSRM table query; no live routing dependency in the request path
  from_id text NOT NULL, to_id text NOT NULL, minutes int NOT NULL CHECK (minutes > 0),
  PRIMARY KEY (from_id, to_id)
);

CREATE TABLE claim_docs (    -- raw untrusted text: stored, hashed, never rendered, never executed
  doc_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sha256 bytea NOT NULL UNIQUE,
  body text NOT NULL CHECK (length(body) <= 20000),
  received_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE evidence_claims (
  claim_id text PRIMARY KEY DEFAULT 'c_' || encode(gen_random_bytes(5), 'hex'),
  place_id text NOT NULL REFERENCES places ON DELETE CASCADE,
  claim_type claim_type NOT NULL,
  value jsonb NOT NULL,
  source_type source_type NOT NULL,
  source_ref text NOT NULL,
  doc_id uuid REFERENCES claim_docs,
  verbatim_span text,
  verified_at timestamptz NOT NULL,
  confidence numeric(3,2) NOT NULL CHECK (confidence BETWEEN 0 AND 1),
  models_agree boolean,
  state claim_state NOT NULL DEFAULT 'PENDING'
);
CREATE INDEX claims_live_ix ON evidence_claims (place_id, claim_type) WHERE state = 'ACCEPTED';

CREATE TABLE adaption_runs (
  dataset_id text PRIMARY KEY, at timestamptz NOT NULL DEFAULT now(), n_rows int NOT NULL,
  grade_before text, grade_after text, improvement_percent numeric
);

CREATE TABLE audit_log (     -- append-only, keyed hash chain (HMAC key lives in the C++ Keyring, not in the DB)
  seq bigserial PRIMARY KEY,
  at timestamptz NOT NULL DEFAULT now(),
  session_id uuid NOT NULL,
  inputs jsonb NOT NULL, excluded jsonb NOT NULL, models jsonb NOT NULL,
  rationale_sha256 bytea NOT NULL,
  prev_mac bytea NOT NULL, mac bytea NOT NULL
);
CREATE FUNCTION audit_immutable() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'audit_log is append-only'; END $$;
CREATE TRIGGER audit_no_row_mutation BEFORE UPDATE OR DELETE ON audit_log FOR EACH ROW EXECUTE FUNCTION audit_immutable();
CREATE TRIGGER audit_no_truncate BEFORE TRUNCATE ON audit_log FOR EACH STATEMENT EXECUTE FUNCTION audit_immutable();

CREATE FUNCTION nearest_service_m(p text, k text, late_only boolean DEFAULT false) RETURNS int
LANGUAGE sql STABLE AS $$
  SELECT round(ST_Distance(s.geog, pl.geog))::int
  FROM places pl JOIN LATERAL (
    SELECT geog FROM services WHERE kind = k AND (NOT late_only OR open_late)
    ORDER BY geog <-> pl.geog LIMIT 1) s ON true
  WHERE pl.place_id = p
$$;

-- Least privilege: the public API can read accepted evidence and append audit rows. Nothing else.
CREATE ROLE yl_api LOGIN;      CREATE ROLE yl_ingest LOGIN;      CREATE ROLE yl_review LOGIN;
GRANT SELECT ON places, services, travel_time, evidence_claims, adaption_runs TO yl_api;
GRANT SELECT (seq, mac) ON audit_log TO yl_api;     -- chain head lookup only
GRANT INSERT ON audit_log TO yl_api;                GRANT USAGE ON SEQUENCE audit_log_seq_seq TO yl_api;
GRANT SELECT ON places TO yl_ingest;
GRANT INSERT ON claim_docs, evidence_claims TO yl_ingest;
GRANT SELECT (doc_id, sha256) ON claim_docs TO yl_ingest;    -- needed for INSERT .. RETURNING / dedupe
GRANT SELECT (claim_id) ON evidence_claims TO yl_ingest;
GRANT SELECT, INSERT ON adaption_runs TO yl_ingest;
GRANT SELECT, UPDATE (state) ON evidence_claims TO yl_review;   -- only reviewers promote PENDING -> ACCEPTED

ALTER TABLE evidence_claims ENABLE ROW LEVEL SECURITY;
CREATE POLICY api_reads_accepted ON evidence_claims FOR SELECT TO yl_api    USING (state = 'ACCEPTED');
CREATE POLICY ingest_pending     ON evidence_claims FOR INSERT TO yl_ingest WITH CHECK (state IN ('PENDING','QUARANTINED'));
CREATE POLICY ingest_sees_own    ON evidence_claims FOR SELECT TO yl_ingest USING (state IN ('PENDING','QUARANTINED'));
CREATE POLICY review_all         ON evidence_claims FOR ALL    TO yl_review USING (true) WITH CHECK (true);
GRANT SELECT ON claim_docs, audit_log, adaption_runs TO yl_review;   -- corpus export + audit verification
GRANT INSERT ON adaption_runs TO yl_review;
