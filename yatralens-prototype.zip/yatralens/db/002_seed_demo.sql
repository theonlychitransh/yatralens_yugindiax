-- DEMO FIXTURES. Names are real Gwalior sites; coordinates are approximate; every claim below is a stand-in
-- (source_ref = 'DEMO-FIXTURE') and MUST be replaced by claims verified against the cited official source.
INSERT INTO places VALUES
 ('hub','Gwalior Junction (start / end)','essential_service', ST_SetSRID(ST_MakePoint(78.1827,26.2152),4326)::geography, 0,false),
 ('gwl_fort','Gwalior Fort','major_landmark',               ST_SetSRID(ST_MakePoint(78.1690,26.2300),4326)::geography,120,false),
 ('tansen_tomb','Tansen''s Tomb','minor_heritage',           ST_SetSRID(ST_MakePoint(78.1830,26.2290),4326)::geography, 45,false),
 ('gopachal_jain','Gopachal Jain rock-cut sculptures','minor_heritage', ST_SetSRID(ST_MakePoint(78.1650,26.2160),4326)::geography, 40,true),
 ('gujari_mahal','Gujari Mahal museum','minor_heritage',     ST_SetSRID(ST_MakePoint(78.1695,26.2310),4326)::geography, 60,false),
 ('craft_demo','Stone-carving workshop (demo)','craft_artisan', ST_SetSRID(ST_MakePoint(78.1500,26.2180),4326)::geography, 60,false);

INSERT INTO services (kind, geog, open_late) SELECT k, ST_SetSRID(ST_MakePoint(x,y),4326)::geography, l FROM (VALUES
 ('PHARMACY',78.1700,26.2250,false),('PHARMACY',78.1810,26.2180,true),('PHARMACY',78.1520,26.2200,false),
 ('BUDGET_FOOD',78.1705,26.2290,false),('BUDGET_FOOD',78.1825,26.2160,true),('BUDGET_FOOD',78.1510,26.2185,false),
 ('AUTO_STAND',78.1830,26.2150,true),('AUTO_STAND',78.1692,26.2298,false)) v(k,x,y,l);

INSERT INTO travel_time   -- placeholder: 1.4x detour at 18 km/h until the OSRM matrix is loaded
SELECT a.place_id, b.place_id, GREATEST(5, ceil(ST_Distance(a.geog,b.geog)*1.4/(18000/60.0)))::int
FROM places a, places b WHERE a.place_id <> b.place_id;

INSERT INTO evidence_claims (place_id,claim_type,value,source_type,source_ref,verified_at,confidence,state) VALUES
 ('gwl_fort','OPERATING_HOURS','{"days":[0,1,2,3,4,5,6],"open":"09:00","close":"17:30"}','OFFICIAL_GOVT','DEMO-FIXTURE',now()-interval '30 days',0.98,'ACCEPTED'),
 ('tansen_tomb','OPERATING_HOURS','{"days":[0,1,2,3,4,5,6],"open":"06:00","close":"18:00"}','OSM_OVERPASS','DEMO-FIXTURE',now()-interval '45 days',0.80,'ACCEPTED'),
 ('craft_demo','OPERATING_HOURS','{"days":[0,1,2,3,4,5],"open":"10:00","close":"18:00"}','OPERATOR_DIRECT','DEMO-FIXTURE',now()-interval '10 days',0.85,'ACCEPTED'),
 ('gujari_mahal','OPERATING_HOURS','{"days":[1,2,3,4,5,6],"open":"10:00","close":"17:00"}','OFFICIAL_GOVT','DEMO-FIXTURE',now()-interval '20 days',0.95,'ACCEPTED'),
 ('gujari_mahal','CLOSURE', jsonb_build_object('from', to_char((now()-interval '2 days') AT TIME ZONE 'Asia/Kolkata','YYYY-MM-DD"T"HH24:MI:SS"+05:30"'),
                                               'until',to_char((now()+interval '25 days') AT TIME ZONE 'Asia/Kolkata','YYYY-MM-DD"T"HH24:MI:SS"+05:30"')),
  'OFFICIAL_GOVT','DEMO-FIXTURE',now()-interval '3 days',0.95,'ACCEPTED'),
 -- expired closure: the only hours claim predates the closure's end, so the site stays blocked until re-verified
 ('gopachal_jain','CLOSURE','{"from":"2026-01-01T00:00:00+05:30","until":"2026-05-31T23:59:00+05:30"}','OFFICIAL_GOVT','DEMO-FIXTURE','2026-04-20T10:00:00+05:30',0.95,'ACCEPTED'),
 ('gopachal_jain','OPERATING_HOURS','{"days":[0,1,2,3,4,5,6],"open":"07:00","close":"18:00"}','OSM_OVERPASS','DEMO-FIXTURE','2026-02-01T10:00:00+05:30',0.70,'ACCEPTED');
