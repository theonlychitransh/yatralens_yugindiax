// ylsec: keyed request authentication + tamper-evident audit chain. pybind11 + OpenSSL 3 (libcrypto only).
//  - key is read from a 0400/0600 file by this module; Python never holds it
//  - HMAC-SHA256 over a canonical request string; CRYPTO_memcmp compare; timestamp skew + nonce replay cache
//  - chain(): mac_n = HMAC(key, mac_{n-1} || payload_n); a DB admin without the key cannot forge or re-link rows
#include <pybind11/pybind11.h>
#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <unistd.h>
#ifdef __linux__
#include <sys/prctl.h>
#endif
#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <mutex>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

namespace py = pybind11;
namespace {
using Mac = std::array<unsigned char, 32>;

std::string to_hex(const unsigned char* p, size_t n) {
  static const char* d = "0123456789abcdef";
  std::string s(n * 2, '0');
  for (size_t i = 0; i < n; ++i) { s[2 * i] = d[p[i] >> 4]; s[2 * i + 1] = d[p[i] & 15]; }
  return s;
}
int nib(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  return -1;  // lowercase hex only: one canonical encoding per MAC
}
bool from_hex(const std::string& h, unsigned char* out, size_t n) {
  if (h.size() != n * 2) return false;
  for (size_t i = 0; i < n; ++i) {
    int a = nib(h[2 * i]), b = nib(h[2 * i + 1]);
    if (a < 0 || b < 0) return false;
    out[i] = static_cast<unsigned char>((a << 4) | b);
  }
  return true;
}
bool clean(const std::string& s, size_t max) {  // no separators / control bytes that could blur field boundaries
  return !s.empty() && s.size() <= max &&
         std::none_of(s.begin(), s.end(), [](unsigned char c) { return c < 0x21 || c == 0x7f; });
}
}  // namespace

class Keyring {
 public:
  explicit Keyring(std::vector<unsigned char> k) : key_(std::move(k)) {
    locked_ = ::mlock(key_.data(), key_.size()) == 0;
  }
  Keyring(const Keyring&) = delete;
  Keyring& operator=(const Keyring&) = delete;
  ~Keyring() {
    OPENSSL_cleanse(key_.data(), key_.size());
    if (locked_) ::munlock(key_.data(), key_.size());
  }

  static std::unique_ptr<Keyring> from_file(const std::string& path) {
    int fd = ::open(path.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) throw std::runtime_error("key file: cannot open");
    struct stat st{};
    if (::fstat(fd, &st) != 0 || !S_ISREG(st.st_mode) || (st.st_mode & (S_IRWXG | S_IRWXO)) != 0 ||
        st.st_uid != ::geteuid()) {
      ::close(fd);
      throw std::runtime_error("key file: must be a regular file, owner-only, owned by this user");
    }
    char buf[256];
    ssize_t n = ::read(fd, buf, sizeof buf);
    ::close(fd);
    std::string hex(buf, n > 0 ? static_cast<size_t>(n) : 0);
    OPENSSL_cleanse(buf, sizeof buf);
    while (!hex.empty() && (hex.back() == '\n' || hex.back() == '\r')) hex.pop_back();
    std::vector<unsigned char> k(32);
    bool ok = from_hex(hex, k.data(), 32);
    OPENSSL_cleanse(hex.data(), hex.size());
    if (!ok) throw std::runtime_error("key file: expected 64 lowercase hex chars (256-bit key)");
    return std::make_unique<Keyring>(std::move(k));
  }

  std::string sign(const std::string& method, const std::string& path, long long ts, const std::string& nonce,
                   const std::string& body) const {
    Mac m = mac(canonical(method, path, ts, nonce, body));
    return to_hex(m.data(), m.size());
  }

  bool verify(const std::string& method, const std::string& path, long long ts, const std::string& nonce,
              const std::string& body, const std::string& sig_hex, long long now, long long skew) {
    Mac got{};
    if (!from_hex(sig_hex, got.data(), got.size())) return false;
    if (ts > now + skew || ts < now - skew) return false;
    Mac want;
    try { want = mac(canonical(method, path, ts, nonce, body)); } catch (const std::invalid_argument&) { return false; }
    if (CRYPTO_memcmp(got.data(), want.data(), want.size()) != 0) return false;  // constant time
    std::lock_guard<std::mutex> g(mu_);  // replay cache is touched only after a valid MAC
    for (auto it = seen_.begin(); it != seen_.end();) it = (it->second < now) ? seen_.erase(it) : std::next(it);
    if (seen_.size() >= 100000) return false;  // fail closed instead of growing without bound
    return seen_.emplace(nonce, ts + skew).second;
  }

  std::string chain(const std::string& prev_hex, const py::bytes& payload) const {
    Mac prev{};
    if (!from_hex(prev_hex, prev.data(), prev.size())) throw std::invalid_argument("prev mac must be 64 hex chars");
    std::string msg(reinterpret_cast<const char*>(prev.data()), prev.size());
    msg += std::string(payload);
    Mac m = mac(msg);
    return to_hex(m.data(), m.size());
  }
  bool locked() const { return locked_; }

 private:
  static std::string canonical(const std::string& method, const std::string& path, long long ts,
                               const std::string& nonce, const std::string& body) {
    if (!clean(method, 7) || !clean(nonce, 64) || !clean(path, 256) || path[0] != '/')
      throw std::invalid_argument("malformed request fields");
    unsigned char h[EVP_MAX_MD_SIZE];
    unsigned int hn = 0;
    if (EVP_Digest(body.data(), body.size(), h, &hn, EVP_sha256(), nullptr) != 1) throw std::runtime_error("sha256");
    return method + "\n" + path + "\n" + std::to_string(ts) + "\n" + nonce + "\n" + to_hex(h, hn);
  }
  Mac mac(const std::string& msg) const {
    Mac out{};
    unsigned int n = 0;
    if (!HMAC(EVP_sha256(), key_.data(), static_cast<int>(key_.size()),
              reinterpret_cast<const unsigned char*>(msg.data()), msg.size(), out.data(), &n) || n != out.size())
      throw std::runtime_error("hmac failed");
    return out;
  }
  std::vector<unsigned char> key_;
  bool locked_ = false;
  std::mutex mu_;
  std::unordered_map<std::string, long long> seen_;
};

static void harden_process() {  // no core dumps, no ptrace/proc-mem reads of the key by same-uid processes
  struct rlimit rl{0, 0};
  ::setrlimit(RLIMIT_CORE, &rl);
#ifdef __linux__
  ::prctl(PR_SET_DUMPABLE, 0);
#endif
}

PYBIND11_MODULE(ylsec, m) {
  m.def("harden_process", &harden_process);
  py::class_<Keyring>(m, "Keyring")
      .def_static("from_file", &Keyring::from_file, py::arg("path"))
      .def("sign", &Keyring::sign, py::call_guard<py::gil_scoped_release>())
      .def("verify", &Keyring::verify, py::call_guard<py::gil_scoped_release>())
      .def("chain", &Keyring::chain)
      .def_property_readonly("locked", &Keyring::locked);
}
