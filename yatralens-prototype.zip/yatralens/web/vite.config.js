import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";

// CSP is injected for production builds only (Vite dev injects inline <style> for HMR).
export default defineConfig(({ mode }) => {
  const api = loadEnv(mode, process.cwd(), "VITE_").VITE_API_URL ?? "";
  const csp = ["default-src 'self'", "script-src 'self'", "style-src 'self'", "img-src 'self' data: https://tile.openstreetmap.org",
    "font-src 'self'", `connect-src 'self' ${api}`, "object-src 'none'", "base-uri 'none'", "form-action 'none'"].join("; ");
  return {
    plugins: [react(), { name: "csp", transformIndexHtml: { order: "post",
      handler: (h) => (mode === "production" ? h.replace("<!--CSP-->", `<meta http-equiv="Content-Security-Policy" content="${csp}">`) : h) } }],
    build: { sourcemap: false },
  };
});
