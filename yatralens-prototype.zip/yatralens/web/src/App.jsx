import { useEffect, useMemo, useRef, useState } from "react";
import { CircleMarker, MapContainer, Polyline, TileLayer, Tooltip, useMap } from "react-leaflet";
import { getCorpus, getPlan } from "./api";

const PERSONAS = [
  ["budget_solo", "Solo, budget", "Public transit, long walks"],
  ["family_mid", "Family, mid-range", "Private auto, services nearby"],
  ["senior_accessible", "Senior", "Short walks, medical access first"],
];
const INTERESTS = [["craft_artisan", "Craft workshops"], ["minor_heritage", "Lesser-known heritage"], ["local_eatery", "Local eateries"]];
const LANGS = [["en", "English"], ["hi", "हिन्दी"], ["mr", "मराठी"], ["kn", "ಕನ್ನಡ"], ["ta", "தமிழ்"], ["bn", "বাংলা"]];
const WHY = {
  NO_VERIFIED_HOURS: "no recent verified hours",
  CLOSED_AT_ARRIVAL: "closed when you would arrive",
  CLOSURE_NOTICE_ACTIVE: "official closure notice covers your visit",
  SENSITIVE_NO_OFFICIAL_PERMIT: "sensitive site, no official entry permission on record",
  ENTRY_RESTRICTED: "entry restricted",
  OVER_TIME_BUDGET: "does not fit your time budget",
  NO_ROUTE_DATA: "no route data",
};
const C = { ok: "#9ece6a", bad: "#f7768e", route: "#7aa2f7", hub: "#bb9af7" };
const today = () => new Date().toLocaleDateString("en-CA");
const short = (id) => `${id.slice(0, 2)}…${id.slice(-4)}`;

function Fit({ pts }) {
  const map = useMap();
  useEffect(() => { if (pts.length > 1) map.fitBounds(pts, { padding: [56, 56] }); }, [pts, map]);
  return null;
}

function MapView({ res }) {
  const hub = res ? [res.hub.lat, res.hub.lng] : [26.2183, 78.1828];
  const route = res ? [hub, ...res.stops.map((s) => [s.lat, s.lng]), hub] : [];
  const pts = useMemo(() => [...route, ...(res?.excluded ?? []).map((x) => [x.lat, x.lng])], [res]); // eslint-disable-line
  return (
    <MapContainer center={hub} zoom={13} className="map" scrollWheelZoom>
      {/* page-wide referrer policy is no-referrer, but OSM's tile policy rejects requests with no Referer: send the origin for tiles only */}
      <TileLayer url="https://tile.openstreetmap.org/{z}/{x}/{y}.png" maxZoom={19} referrerPolicy="origin" attribution="© OpenStreetMap contributors" />
      {res && <Fit pts={pts} />}
      {res && <Polyline positions={route} pathOptions={{ color: C.route, weight: 2, dashArray: "6 6" }} />}
      {res && <CircleMarker center={hub} radius={6} pathOptions={{ color: C.hub, fillOpacity: 1 }}><Tooltip>{res.hub.name}</Tooltip></CircleMarker>}
      {res?.stops.map((s, i) => (
        <CircleMarker key={s.id} center={[s.lat, s.lng]} radius={11} pathOptions={{ color: C.ok, fillColor: "#1a1b26", fillOpacity: 1, weight: 2 }}>
          <Tooltip permanent direction="center" className="stopnum">{i + 1}</Tooltip>
        </CircleMarker>
      ))}
      {res?.excluded.map((x) => (
        <CircleMarker key={x.id} center={[x.lat, x.lng]} radius={9} pathOptions={{ color: C.bad, fillColor: C.bad, fillOpacity: 0.25, weight: 2 }}>
          <Tooltip>{x.name}: {x.codes.map((c) => WHY[c] ?? c).join("; ")}</Tooltip>
        </CircleMarker>
      ))}
    </MapContainer>
  );
}

function Note({ text, onCite }) {  // React escapes everything; citations become buttons
  return <p className="note" lang="und">{text.split(/(\[C:c_[0-9a-f]{10}\])/).map((p, i) => {
    const m = p.match(/^\[C:(c_[0-9a-f]{10})\]$/);
    return m ? <button key={i} type="button" className="chip" onClick={() => onCite(m[1])}>{short(m[1])}</button> : <span key={i}>{p}</span>;
  })}</p>;
}

export default function App() {
  const [f, setF] = useState({ persona: "budget_solo", time_budget_h: 6, start_hour: 9, day: today(), interests: ["craft_artisan", "minor_heritage"], lang: "en" });
  const [res, setRes] = useState(null);
  const [state, setState] = useState("idle");
  const [err, setErr] = useState("");
  const [claim, setClaim] = useState(null);
  const [corpus, setCorpus] = useState(null);
  const ctl = useRef(null);
  const set = (k, v) => setF((o) => ({ ...o, [k]: v }));

  useEffect(() => {
    const c = new AbortController();
    getCorpus(c.signal).then((r) => setCorpus(r.adaption)).catch(() => {});
    return () => c.abort();
  }, []);

  async function run(e) {
    e.preventDefault();
    ctl.current?.abort();
    const c = (ctl.current = new AbortController());
    setState("loading"); setErr(""); setClaim(null);
    try { setRes(await getPlan(f, c.signal)); setState("done"); }
    catch (x) { if (x.name !== "AbortError") { setErr(x.message); setState("error"); } }
  }

  const rows = res ? [
    ...res.stops.map((s) => ({ id: s.id, sev: s.conf < 0.7 ? "warn" : "ok", msg: `${s.arrive}–${s.depart}  score ${s.v}  evidence ${s.conf}${s.conf < 0.7 ? " (limited)" : ""}`, cites: s.cites })),
    ...res.excluded.map((x) => ({ id: x.id, sev: "error", msg: x.codes.map((c) => WHY[c] ?? c).join("; "), cites: x.cites })),
  ] : [];
  const ev = claim && res?.evidence[claim];

  return (
    <div className="app">
      <form className="rail" onSubmit={run}>
        <h1>YatraLens</h1>
        <p className="sub">Plans a day only from evidence it can show you.</p>
        <fieldset>
          <legend>Traveller</legend>
          {PERSONAS.map(([v, l, d]) => (
            <label key={v} className="opt"><input type="radio" name="persona" checked={f.persona === v} onChange={() => set("persona", v)} /><span>{l}<small>{d}</small></span></label>
          ))}
        </fieldset>
        <label className="fld">Time available: <b>{f.time_budget_h} h</b>
          <input type="range" min="2" max="10" value={f.time_budget_h} onChange={(e) => set("time_budget_h", +e.target.value)} />
        </label>
        <div className="two">
          <label className="fld">Start
            <select value={f.start_hour} onChange={(e) => set("start_hour", +e.target.value)}>
              {Array.from({ length: 12 }, (_, i) => i + 5).map((h) => <option key={h} value={h}>{String(h).padStart(2, "0")}:00</option>)}
            </select></label>
          <label className="fld">Day
            <input type="date" value={f.day} min={today()} onChange={(e) => set("day", e.target.value)} required /></label>
        </div>
        <fieldset>
          <legend>Interests</legend>
          {INTERESTS.map(([v, l]) => (
            <label key={v} className="opt"><input type="checkbox" checked={f.interests.includes(v)}
              onChange={(e) => set("interests", e.target.checked ? [...f.interests, v] : f.interests.filter((x) => x !== v))} /><span>{l}</span></label>
          ))}
        </fieldset>
        <label className="fld">Note language
          <select value={f.lang} onChange={(e) => set("lang", e.target.value)}>{LANGS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label>
        <button className="go" disabled={state === "loading"}>{state === "loading" ? "Checking evidence…" : "Plan the day"}</button>
        <p className="foot">{corpus ? `Evidence corpus on Adaption: quality ${corpus.grade_before} → ${corpus.grade_after} (${corpus.improvement_percent.toFixed(0)}% better, ${corpus.n_rows} rows)` : "No Adaption quality run recorded yet."}</p>
      </form>

      <main className="stage"><MapView res={res} /></main>

      <aside className="trace" aria-live="polite">
        <header><h2>Gate trace</h2>{res && <span className="meta">{res.total_min} min · {res.models.join(" + ")}</span>}</header>
        {state === "error" && <p className="err" role="alert">{err} Check that the API is running, then try again.</p>}
        {state === "idle" && <p className="empty">Choose your constraints and run the plan. Every site is gated on closures, verified hours and entry permission before it can appear.</p>}
        {res && <Note text={res.note} onCite={setClaim} />}
        <ol className="diag" key={res?.session}>
          {rows.map((r, i) => (
            <li key={r.id} className={r.sev} style={{ "--i": i }}>
              <span className="gut">{i + 1}</span><span className="sev">{r.sev}</span>
              <span className="who">{r.id}</span><span className="msg">{r.msg}</span>
              <span className="cites">{r.cites.map((c) => <button key={c} type="button" className="chip" onClick={() => setClaim(c)}>{short(c)}</button>)}</span>
            </li>
          ))}
        </ol>
        {ev && (
          <section className="evid" aria-label="Evidence record">
            <h3>{claim} <button type="button" className="x" onClick={() => setClaim(null)} aria-label="Close evidence">×</button></h3>
            {ev.demo && <p className="demo">Demo fixture. Not a verified source.</p>}
            <dl><dt>Type</dt><dd>{ev.type}</dd><dt>Source</dt><dd>{ev.source}</dd><dt>Reference</dt><dd>{ev.ref}</dd>
              <dt>Verified</dt><dd>{new Date(ev.verified_at).toLocaleString()}</dd></dl>
            <pre>{JSON.stringify(ev.value, null, 2)}</pre>
          </section>
        )}
      </aside>
    </div>
  );
}
