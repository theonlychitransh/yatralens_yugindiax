const API = import.meta.env.VITE_API_URL ?? "";
const opts = { credentials: "omit", referrerPolicy: "no-referrer", cache: "no-store" };

async function call(path, init, signal) {
  const r = await fetch(`${API}${path}`, { ...opts, ...init, signal });
  if (!r.ok) throw new Error(r.status === 429 ? "Too many requests. Wait a minute." : `Request failed (${r.status})`);
  return r.json();
}
export const getPlan = (body, signal) =>
  call("/v1/plan", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) }, signal);
export const getCorpus = (signal) => call("/v1/corpus-quality", {}, signal);
