"""Recompute the audit chain with the audit key. Non-zero exit on any tampering."""
import os, sys

import psycopg
from psycopg.rows import dict_row

from app import audit, seclib as ylsec

kr = ylsec.Keyring.from_file(os.environ.get("YL_AUDIT_KEYFILE", "/run/secrets/yl_audit_key"))
with psycopg.connect(os.environ["YL_REVIEW_DATABASE_URL"], row_factory=dict_row) as c:
    ok, n = audit.verify(c, kr)
print("chain intact, rows:" if ok else "TAMPER at seq", n)
sys.exit(0 if ok else 1)
