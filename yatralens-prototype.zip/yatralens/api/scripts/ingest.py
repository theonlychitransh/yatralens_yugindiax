"""Signed ingest client (holds the admin key only via the C++ Keyring).
python scripts/ingest.py URL PLACE_ID SOURCE_TYPE SOURCE_REF OBSERVED_AT_ISO FILE"""
import json, secrets, sys, time

import httpx
from app import seclib as ylsec

url, place, st, ref, obs, file = sys.argv[1:7]
kr = ylsec.Keyring.from_file("/run/secrets/yl_admin_key")
body = json.dumps({"place_id": place, "source_type": st, "source_ref": ref, "observed_at": obs, "body": open(file, encoding="utf-8").read()}).encode()
ts, nonce = int(time.time()), secrets.token_hex(16)
path = "/v1/ingest"
sig = kr.sign("POST", path, ts, nonce, body)
r = httpx.post(url + path, content=body, headers={"content-type": "application/json", "x-yl-ts": str(ts), "x-yl-nonce": nonce, "x-yl-sig": sig}, timeout=30)
print(r.status_code, r.text)
