"""One-process prototype launcher: API + built web UI on 127.0.0.1, then opens the browser.
Runs from source (python launcher.py) or frozen by PyInstaller (see ../build.sh). Demo mode unless YL_DATABASE_URL is set."""
import os, socket, sys, threading, time, webbrowser
from pathlib import Path


def base() -> Path:
    return Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))


def find_static() -> str:
    for c in (base() / "web", base().parent / "web" / "dist"):
        if (c / "index.html").is_file():
            return str(c)
    sys.exit("web UI not found: run ./build.sh (it builds web/dist first)")


def free_port(want: int) -> int:
    for p in (want, 0):
        with socket.socket() as s:
            try:
                s.bind(("127.0.0.1", p)); return s.getsockname()[1]
            except OSError:
                continue
    raise RuntimeError("no free port")


def main() -> None:
    os.environ.setdefault("YL_STATIC_DIR", find_static())
    port = free_port(int(os.environ.get("PORT", "8000")))
    os.environ.setdefault("YL_WEB_ORIGIN", f"http://127.0.0.1:{port}")
    import uvicorn
    from app.main import DEMO, app
    url = f"http://127.0.0.1:{port}/"
    print(f"YatraLens prototype ({'demo data, in-memory' if DEMO else 'Postgres'}) -> {url}   (Ctrl+C to stop)")
    if not os.environ.get("YL_NO_BROWSER"):
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning", log_config=None)


if __name__ == "__main__":
    main()
