"""Offline tests: engine on demo fixtures, guards, fallback crypto, in-memory audit chain. No Postgres/FastAPI needed."""
import sys, uuid
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import demo, guard, seclib
from app.engine import IST, plan

NOW = datetime.now(timezone.utc)


def run(persona="budget_solo", ints=("craft_artisan", "minor_heritage"), hours=6, start=9, days=1):
    places, claims, tt = demo.load_world(NOW)
    d = (NOW.astimezone(IST) + timedelta(days=days)).date()
    return plan(places, claims, tt, d, start, hours, persona, set(ints), NOW), claims


def test_plan_obeys_gates():
    res, _ = run()
    ids = [s.place_id for s in res.stops]
    assert ids, "demo day should produce at least one stop"
    assert "gujari_mahal" not in ids and res.excluded["gujari_mahal"]["codes"] == ["CLOSURE_NOTICE_ACTIVE"]
    assert "gopachal_jain" in res.excluded and "NO_VERIFIED_HOURS" in res.excluded["gopachal_jain"]["codes"]
    assert all(s.cites for s in res.stops)


def test_time_budget_respected():
    res, _ = run(hours=2)
    assert res.total_min <= 120


def test_fallback_crypto_roundtrip_and_replay():
    kr = seclib.PyKeyring.ephemeral()
    sig = kr.sign("POST", "/v1/ingest", 1000, "n1", b"{}")
    assert kr.verify("POST", "/v1/ingest", 1000, "n1", b"{}", sig, 1000, 60)
    assert not kr.verify("POST", "/v1/ingest", 1000, "n1", b"{}", sig, 1000, 60)      # replay
    assert not kr.verify("POST", "/v1/ingest", 1000, "n2", b"{}", sig, 1000, 60)      # wrong nonce
    s2 = kr.sign("POST", "/v1/ingest", 1000, "n3", b"{}")
    assert not kr.verify("POST", "/v1/ingest", 1000, "n3", b"{}", s2, 2000, 60)       # stale


def test_audit_chain_detects_tamper():
    kr, a = seclib.PyKeyring.ephemeral(), demo.DemoAudit()
    for i in range(3):
        a.append(kr, uuid.uuid4(), {"i": i}, {}, {"models": ["template"]}, f"note {i}")
    assert a.verify(kr) == (True, 3)
    a.rows[1]["inputs"]["i"] = 99
    assert a.verify(kr) == (False, 2)


def test_note_validator():
    f = {"stops": [{"place": "Fort", "arrive": "09:20", "cite": "c_0123456789"}], "excluded": []}
    assert guard.validate_note("Fort 09:20 [C:c_0123456789].", f)
    assert not guard.validate_note("Fort opens 10:00 [C:c_0123456789].", f)       # invented number
    assert not guard.validate_note("Fort 09:20 [C:c_ffffffffff].", f)             # unknown citation
    assert not guard.validate_note("Fort 09:20.", f)                              # uncited number
