"""Public API (role yl_api, audit key). No write path to evidence; no admin credentials in this process."""
import os, uuid
import contextlib
from contextlib import asynccontextmanager
from datetime import date, datetime, timezone
from typing import Literal

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict, Field
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

from . import audit, demo, guard, seclib as ylsec
from .config import cfg
from .engine import IST, plan
from .world import load_world, pool

try:                                    # LLMs are optional: no SDK or no API key -> deterministic template note
    from . import llm
except Exception:                       # pragma: no cover
    llm = None

DEMO = not cfg.database_url              # no Postgres configured -> in-memory fixtures (prototype mode)
STATIC_DIR = os.environ.get("YL_STATIC_DIR", "")

ylsec.harden_process()
try:
    keyring = ylsec.Keyring.from_file(cfg.audit_keyfile)
except Exception:
    if not DEMO:
        raise                            # production must never fall back to an ephemeral key
    keyring = ylsec.PyKeyring.ephemeral()
demo_audit = demo.DemoAudit()
limiter = Limiter(key_func=get_remote_address)


@asynccontextmanager
async def lifespan(_):
    if not DEMO:
        pool.open()
    yield
    if not DEMO:
        pool.close()


app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(CORSMiddleware, allow_origins=[cfg.web_origin], allow_methods=["GET", "POST"],
                   allow_headers=["content-type"], allow_credentials=False)
guard.harden(app)


class PlanReq(BaseModel):
    model_config = ConfigDict(extra="forbid")
    persona: Literal["budget_solo", "family_mid", "senior_accessible"]
    time_budget_h: int = Field(ge=2, le=10)
    start_hour: int = Field(ge=5, le=16)
    day: date
    interests: list[Literal["craft_artisan", "minor_heritage", "local_eatery"]] = Field(max_length=3)
    lang: Literal["en", "hi", "mr", "kn", "ta", "bn"] = "en"


def _hhmm(d: datetime) -> str:
    return d.astimezone(IST).strftime("%H:%M")


def _facts(res, persona: str) -> dict:
    return {"persona": persona, "confidence_note": "LIMITED_EVIDENCE" if res.limited else "OK",
            "stops": [{"place": s.name, "arrive": _hhmm(s.arrive), "depart": _hhmm(s.depart),
                       "hours": f"{s.open}-{s.close}", "cite": s.cites[0]} for s in res.stops],
            "excluded": [{"place": res.names[k], "codes": v["codes"], "cite": (v["cites"] or [None])[0]} for k, v in res.excluded.items()],
            "risks": res.risks}


def _template(f: dict) -> str:   # deterministic fallback: same validator, no LLM
    out = ["Limited evidence:"] if f["confidence_note"] == "LIMITED_EVIDENCE" else []
    out += [f'{s["place"]} {s["arrive"]}-{s["depart"]}, open {s["hours"]} [C:{s["cite"]}].' for s in f["stops"]]
    out += [f'{e["place"]} excluded: {", ".join(c.lower().replace("_", " ") for c in e["codes"])}'
            + (f' [C:{e["cite"]}]' if e["cite"] else "") + "." for e in f["excluded"]]
    return " ".join(out)


def _narrate(f: dict, lang: str) -> tuple[str, list[str]]:
    used = []
    try:
        if llm is None or not os.environ.get("ANTHROPIC_API_KEY"):
            raise RuntimeError("no Claude key: use template")
        note = llm.explain(f)
        if not guard.validate_note(note, f):
            raise ValueError("note failed validation")
        used.append(cfg.claude_judge)
    except Exception:
        note = _template(f); used.append("template")
    if lang != "en" and llm is not None and os.environ.get("GEMINI_API_KEY"):
        try:
            t = llm.translate(note, lang)
            if guard.same_facts(note, t):
                note = t; used.append(cfg.gemini_model)
        except Exception:
            pass
    return note, used


@app.get("/healthz")
def healthz():
    return {"ok": True, "key_pinned": keyring.locked, "mode": "demo" if DEMO else "postgres", "native_sec": ylsec.NATIVE}


@app.get("/v1/corpus-quality")
def corpus_quality():
    if DEMO:
        return {"adaption": None}
    with pool.connection() as c:
        r = c.execute("SELECT n_rows, grade_before, grade_after, improvement_percent, at FROM adaption_runs ORDER BY at DESC LIMIT 1").fetchone()
    return {"adaption": r and {**r, "improvement_percent": float(r["improvement_percent"] or 0), "at": r["at"].isoformat()}}


@app.post("/v1/plan")
@limiter.limit("20/minute")
def make_plan(request: Request, req: PlanReq):
    now = datetime.now(timezone.utc)
    if abs((req.day - now.astimezone(IST).date()).days) > 30:
        raise HTTPException(422, "day must be within 30 days of today")
    with (contextlib.nullcontext() if DEMO else pool.connection()) as conn:
        places, claims, tt = demo.load_world(now) if DEMO else load_world(conn)
        res = plan(places, claims, tt, req.day, req.start_hour, req.time_budget_h, req.persona, set(req.interests), now)
        res.names = {p.place_id: p.name for p in places}
        facts = _facts(res, req.persona)
        note, used = _narrate(facts, req.lang)
        by_id = {c.claim_id: c for cs in claims.values() for c in cs}
        ev = {cid: {"type": c.ctype, "value": c.value, "source": c.source_type, "ref": c.source_ref,
                    "verified_at": c.verified_at.isoformat(), "demo": c.source_ref.startswith("DEMO-FIXTURE")}
              for s in res.stops for cid in s.cites for c in [by_id[cid]]}
        ev.update({cid: {"type": by_id[cid].ctype, "value": by_id[cid].value, "source": by_id[cid].source_type,
                         "ref": by_id[cid].source_ref, "verified_at": by_id[cid].verified_at.isoformat(),
                         "demo": by_id[cid].source_ref.startswith("DEMO-FIXTURE")}
                   for v in res.excluded.values() for cid in v["cites"]})
        sid = uuid.uuid4()
        (demo_audit.append(keyring, sid, {"persona": req.persona, "budget_h": req.time_budget_h, "start": req.start_hour,
                                          "day": req.day.isoformat(), "interests": sorted(req.interests), "lang": req.lang},
                     res.excluded, {"models": used, "stops": [s.place_id for s in res.stops]}, note)
         if DEMO else audit.append(conn, keyring, sid, {"persona": req.persona, "budget_h": req.time_budget_h, "start": req.start_hour,
                                          "day": req.day.isoformat(), "interests": sorted(req.interests), "lang": req.lang},
                     res.excluded, {"models": used, "stops": [s.place_id for s in res.stops]}, note))
    pl = {p.place_id: p for p in places}
    hub = pl["hub"]
    return {"session": str(sid), "hub": {"lat": hub.lat, "lng": hub.lng, "name": hub.name}, "note": note, "models": used,
            "total_min": res.total_min, "limited": res.limited,
            "stops": [{"id": s.place_id, "name": s.name, "category": s.category, "lat": s.lat, "lng": s.lng,
                       "arrive": _hhmm(s.arrive), "depart": _hhmm(s.depart), "v": s.v, "sub": s.sub, "cites": s.cites, "conf": s.conf}
                      for s in res.stops],
            "excluded": [{"id": k, "name": res.names[k], "lat": pl[k].lat, "lng": pl[k].lng, **v} for k, v in res.excluded.items()],
            "evidence": ev}


if STATIC_DIR and os.path.isdir(STATIC_DIR):        # single-process prototype: the same origin serves the built web UI
    from fastapi.staticfiles import StaticFiles
    app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="web")
