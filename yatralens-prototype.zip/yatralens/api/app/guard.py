"""Boundary controls for untrusted text in, and for model text out."""
import json, re, secrets, unicodedata
from collections import Counter

_INVISIBLE = re.compile("[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u2064\u2066-\u2069\ufeff]")
_CITE = re.compile(r"\[C:(c_[0-9a-f]{10})\]")
_SENT = re.compile(r"(?<=[.!?])\s+")


def canon(s: str) -> str:
    """NFKC, strip control / zero-width / bidi chars (Trojan Source), collapse whitespace, defang angle brackets."""
    s = _INVISIBLE.sub("", unicodedata.normalize("NFKC", s))
    return re.sub(r"\s+", " ", s).strip().replace("<", "\u2039").replace(">", "\u203a")


def wrap_untrusted(doc: str, cap: int = 6000) -> str:
    return f'<untrusted_document id="{secrets.token_hex(8)}">\n{canon(doc)[:cap]}\n</untrusted_document>'


def validate_note(text: str, facts: dict) -> bool:
    """Reject any model note that cites an unknown claim or states a number the engine did not produce."""
    if not text or len(text) > 1200 or re.search(r"https?://|[<>`]", text):
        return False
    blob = json.dumps(facts, ensure_ascii=False)
    if text.count("[C:") != len(_CITE.findall(text)) or set(_CITE.findall(text)) - set(re.findall(r"c_[0-9a-f]{10}", blob)):
        return False
    allowed = set(re.findall(r"\d+", blob))
    for s in _SENT.split(text):
        nums = re.findall(r"\d+", _CITE.sub("", s))
        if nums and (not _CITE.search(s) or set(nums) - allowed):
            return False
    return True


def same_facts(src: str, dst: str) -> bool:
    """Translation must keep cite tags and digits identical (also rejects non-ASCII numerals)."""
    sig = lambda t: (Counter(_CITE.findall(t)), Counter(re.findall(r"\d+", _CITE.sub("", t))))
    return bool(dst) and len(dst) < 4000 and sig(src) == sig(dst)


def harden(app):
    @app.middleware("http")
    async def _headers(request, call_next):
        r = await call_next(request)
        if request.url.path.startswith(("/v1/", "/healthz")):   # API responses: no content at all. Static UI carries its own CSP <meta>.
            r.headers["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none'"
        else:
            r.headers["Content-Security-Policy"] = "frame-ancestors 'none'"
        r.headers.update({
            "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer", "Cache-Control": "no-store",
            "Strict-Transport-Security": "max-age=63072000; includeSubDomains"})
        return r
