"""Evidence corpus -> Adaption Adaptive Data -> measured quality + held-out stress suite.
Flow per Adaption's SDK docs: upload_file -> get_status -> run(column_mapping, job_specification) -> wait_for_completion
-> get(evaluation_summary) -> download.  Hard gates never learn from adapted data; it feeds bench.py and the corpus-quality badge.
Run:  python -m app.adaption_loop --estimate-only     then     python -m app.adaption_loop --max-rows 500"""
import argparse, json, os, pathlib, tempfile, time

import httpx, psycopg
from adaption import Adaption
from psycopg.rows import dict_row

from .config import cfg
from .guard import canon

MAX_CREDITS = float(os.environ.get("YL_ADAPTION_MAX_CREDITS", "50"))
ROWS_SQL = """SELECT d.body, jsonb_agg(jsonb_build_object('claim_type', c.claim_type, 'value', c.value) ORDER BY c.claim_id) AS claims
  FROM claim_docs d JOIN evidence_claims c USING (doc_id)
  WHERE c.state = 'ACCEPTED' AND c.models_agree GROUP BY d.doc_id, d.body"""     # only machine- AND human-vetted rows


def export_rows(conn, path: pathlib.Path) -> int:
    n = 0
    with path.open("w", encoding="utf-8") as f:
        for r in conn.execute(ROWS_SQL):
            f.write(json.dumps({"prompt": canon(r["body"]), "completion": json.dumps(r["claims"], sort_keys=True)}, ensure_ascii=False) + "\n")
            n += 1
    return n


def cycle(max_rows: int, estimate_only: bool) -> None:
    with psycopg.connect(cfg.review_database_url, row_factory=dict_row) as conn:
        path = pathlib.Path(tempfile.mkdtemp()) / "yl_evidence.jsonl"
        n = export_rows(conn, path)
        if n < 20:
            raise SystemExit(f"{n} vetted rows: too few to adapt")
        client = Adaption(api_key=os.environ["ADAPTION_API_KEY"])
        up = client.datasets.upload_file(str(path))
        t0 = time.time()
        while client.datasets.get_status(up.dataset_id).row_count is None:     # ingestion is async: poll
            if time.time() - t0 > 300:
                raise TimeoutError("Adaption ingestion")
            time.sleep(2)
        args = dict(column_mapping={"prompt": "prompt", "completion": "completion"}, job_specification={"max_rows": max_rows})
        est = client.datasets.run(up.dataset_id, estimate=True, **args)        # no credits consumed; confirm kwarg in the SDK reference
        print(f"estimate: {est.estimated_credits_consumed} credits, ~{est.estimated_minutes} min")
        if est.estimated_credits_consumed > MAX_CREDITS:
            raise SystemExit("estimate exceeds YL_ADAPTION_MAX_CREDITS")
        if estimate_only:
            return
        client.datasets.run(up.dataset_id, **args)
        client.datasets.wait_for_completion(up.dataset_id, timeout=3600)
        ev = client.datasets.get(up.dataset_id).evaluation_summary
        conn.execute("INSERT INTO adaption_runs (dataset_id,n_rows,grade_before,grade_after,improvement_percent) VALUES (%s,%s,%s,%s,%s)",
                     (up.dataset_id, n, str(ev.grade_before), str(ev.grade_after), ev.improvement_percent))
        conn.commit()
        url = client.datasets.download(up.dataset_id)
        if not url.startswith("https://"):
            raise SystemExit("refusing non-https download URL")
        out = pathlib.Path("data/adapted.jsonl"); out.parent.mkdir(exist_ok=True)
        with httpx.stream("GET", url, timeout=120, follow_redirects=False) as r:   # presigned URL; size-capped
            r.raise_for_status(); size = 0
            with out.open("wb") as f:
                for chunk in r.iter_bytes():
                    size += len(chunk)
                    if size > 50_000_000:
                        raise SystemExit("download exceeds 50 MB cap")
                    f.write(chunk)
        print(f"grade {ev.grade_before} -> {ev.grade_after}; saved {out}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--max-rows", type=int, default=500); ap.add_argument("--estimate-only", action="store_true")
    a = ap.parse_args(); cycle(a.max_rows, a.estimate_only)
