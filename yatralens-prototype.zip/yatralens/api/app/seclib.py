"""Security primitives. Uses the hardened C++ module `ylsec` when it is built and importable; otherwise a pure-Python
fallback with the SAME wire format (HMAC-SHA256, same canonical string, same chain), so chains/signatures interoperate.
The fallback has no mlock/cleanse guarantees: prototype and demo use only."""
import hashlib, hmac, os, secrets, stat, sys, threading

try:                                    # production path
    import ylsec as _native
except ImportError:                     # prototype path
    _native = None

NATIVE = _native is not None


def _hex(b: bytes) -> str:
    return b.hex()


def _clean(s: str, mx: int) -> bool:
    return 0 < len(s) <= mx and all(0x21 <= ord(c) < 0x7F for c in s)


class PyKeyring:
    locked = False

    def __init__(self, key: bytes):
        if len(key) != 32:
            raise ValueError("expected a 256-bit key")
        self._key, self._seen, self._mu = key, {}, threading.Lock()

    @classmethod
    def ephemeral(cls) -> "PyKeyring":           # demo mode: a fresh key per process; the audit chain lives in memory too
        return cls(secrets.token_bytes(32))

    @classmethod
    def from_file(cls, path: str) -> "PyKeyring":
        st = os.stat(path)
        if not stat.S_ISREG(st.st_mode):
            raise RuntimeError("key file: must be a regular file")
        if os.name == "posix" and ((st.st_mode & 0o077) or st.st_uid != os.geteuid()):
            raise RuntimeError("key file: must be owner-only and owned by this user")
        h = open(path, "r").read().strip()
        if len(h) != 64 or h != h.lower() or any(c not in "0123456789abcdef" for c in h):
            raise RuntimeError("key file: expected 64 lowercase hex chars (256-bit key)")
        return cls(bytes.fromhex(h))

    def _mac(self, msg: bytes) -> bytes:
        return hmac.new(self._key, msg, hashlib.sha256).digest()

    @staticmethod
    def _canonical(method: str, path: str, ts: int, nonce: str, body: bytes) -> bytes:
        if not (_clean(method, 7) and _clean(nonce, 64) and _clean(path, 256) and path[0] == "/"):
            raise ValueError("malformed request fields")
        return f"{method}\n{path}\n{ts}\n{nonce}\n{hashlib.sha256(body).hexdigest()}".encode()

    def sign(self, method, path, ts, nonce, body) -> str:
        return _hex(self._mac(self._canonical(method, path, ts, nonce, _b(body))))

    def verify(self, method, path, ts, nonce, body, sig_hex, now, skew) -> bool:
        if len(sig_hex) != 64 or any(c not in "0123456789abcdef" for c in sig_hex) or abs(ts - now) > skew:
            return False
        try:
            want = self._mac(self._canonical(method, path, ts, nonce, _b(body)))
        except ValueError:
            return False
        if not hmac.compare_digest(bytes.fromhex(sig_hex), want):
            return False
        with self._mu:
            self._seen = {k: v for k, v in self._seen.items() if v >= now}
            if len(self._seen) >= 100_000 or nonce in self._seen:
                return False
            self._seen[nonce] = ts + skew
            return True

    def chain(self, prev_hex: str, payload: bytes) -> str:
        if len(prev_hex) != 64:
            raise ValueError("prev mac must be 64 hex chars")
        return _hex(self._mac(bytes.fromhex(prev_hex) + bytes(payload)))


def _b(x) -> bytes:
    return x if isinstance(x, (bytes, bytearray)) else str(x).encode()


def harden_process() -> None:
    if _native:
        return _native.harden_process()
    if os.name == "posix":
        try:
            import resource
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        except Exception:
            pass


Keyring = _native.Keyring if _native else PyKeyring
