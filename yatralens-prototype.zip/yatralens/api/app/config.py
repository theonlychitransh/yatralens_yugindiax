from pydantic_settings import BaseSettings, SettingsConfigDict


class Cfg(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="YL_")
    # one DSN per process/role; DSNs carry sslmode=verify-full + client cert (mTLS to Postgres)
    database_url: str = ""          # public API  -> role yl_api
    ingest_database_url: str = ""   # admin API   -> role yl_ingest
    review_database_url: str = ""   # CLI jobs    -> role yl_review
    audit_keyfile: str = "/run/secrets/yl_audit_key"   # 64 hex chars, mode 0400, read by ylsec only
    admin_keyfile: str = "/run/secrets/yl_admin_key"   # a different key: public-process compromise cannot call admin
    web_origin: str = "https://localhost:5173"
    # Provider keys come from env (GEMINI_API_KEY, ANTHROPIC_API_KEY, ADAPTION_API_KEY), never from code or the browser.
    gemini_model: str = "gemini-3-flash-preview"     # extractor + translator
    claude_sentinel: str = "claude-haiku-5-5"        # injection / PII screen
    claude_judge: str = "claude-sonnet-5-5"          # second extractor, adjudicator, explainer
    llm_timeout_s: float = 6.0


cfg = Cfg()
