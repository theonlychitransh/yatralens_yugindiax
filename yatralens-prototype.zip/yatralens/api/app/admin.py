"""Internal ingest API (role yl_ingest, admin key). Bind to a private interface only. HMAC-signed requests (C++ ylsec)."""
import hashlib, time
from datetime import datetime, timezone
from typing import Literal

import psycopg
from fastapi import Depends, FastAPI, HTTPException, Request
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb
from pydantic import BaseModel, ConfigDict, Field

from . import guard, llm, seclib as ylsec
from .config import cfg

ylsec.harden_process()
keyring = ylsec.Keyring.from_file(cfg.admin_keyfile)
app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
guard.harden(app)
PRIOR = {"OFFICIAL_GOVT": 0.95, "OPERATOR_DIRECT": 0.80, "OSM_OVERPASS": 0.60, "VERIFIED_USER_OBSERVATION": 0.50}


async def signed(request: Request):
    body = await request.body()
    if len(body) > 65536:
        raise HTTPException(413, "too large")
    h = request.headers
    try:
        ok = keyring.verify(request.method, request.url.path, int(h["x-yl-ts"]), h["x-yl-nonce"], body,
                            h["x-yl-sig"], int(time.time()), 60)
    except (KeyError, ValueError):
        ok = False
    if not ok:
        raise HTTPException(401, "unauthorized")


class IngestReq(BaseModel):
    model_config = ConfigDict(extra="forbid")
    place_id: str = Field(pattern=r"^[a-z0-9_]{3,64}$")
    source_type: Literal["OFFICIAL_GOVT", "OPERATOR_DIRECT", "OSM_OVERPASS", "VERIFIED_USER_OBSERVATION"]
    source_ref: str = Field(min_length=3, max_length=300)
    observed_at: datetime                      # when the source says this was true; becomes verified_at
    body: str = Field(min_length=20, max_length=20000)


def _iso(s) -> bool:
    try:
        return datetime.fromisoformat(s).tzinfo is not None
    except (TypeError, ValueError):
        return False


def _value(c: llm.XClaim) -> dict | None:
    if c.claim_type == "OPERATING_HOURS" and c.days and c.open and c.close:
        return {"days": c.days, "open": c.open, "close": c.close}
    if c.claim_type == "CLOSURE" and _iso(c.date_from) and _iso(c.date_until):
        return {"from": c.date_from, "until": c.date_until}
    if c.claim_type == "ENTRY_RESTRICTION" and c.entry_allowed is not None:
        return {"entry_allowed": c.entry_allowed}
    return None                                # incomplete or unsupported claims are dropped, never guessed


@app.post("/v1/ingest", dependencies=[Depends(signed)])
def ingest(req: IngestReq):
    if req.observed_at.tzinfo is None or req.observed_at > datetime.now(timezone.utc):
        raise HTTPException(422, "observed_at must be timezone-aware and not in the future")
    verdict = llm.sentinel(req.body)           # Claude Haiku first: nothing reaches an extractor on 'block'
    sha = hashlib.sha256(guard.canon(req.body).encode()).digest()
    rows, flags = [], set()
    if verdict.verdict != "block":
        pairs, flags = llm.dual_extract(req.body)  # Gemini + Claude Sonnet, value-for-value agreement
        for c, agree in pairs:
            v = _value(c)
            if v:
                conf = PRIOR[req.source_type] if agree and "SUSPECT" not in flags else min(PRIOR[req.source_type], 0.40)
                rows.append((req.place_id, c.claim_type, Jsonb(v), req.source_type, req.source_ref, c.verbatim_span,
                             req.observed_at, conf, agree))
    state = "PENDING" if verdict.verdict == "allow" else "QUARANTINED"
    with psycopg.connect(cfg.ingest_database_url, row_factory=dict_row) as conn, conn.transaction():
        conn.execute("INSERT INTO claim_docs (sha256, body) VALUES (%s,%s) ON CONFLICT (sha256) DO NOTHING", (sha, guard.canon(req.body)))
        doc = conn.execute("SELECT doc_id FROM claim_docs WHERE sha256 = %s", (sha,)).fetchone()["doc_id"]
        for r in rows:   # parameterised; promotion PENDING -> ACCEPTED needs the separate yl_review role
            conn.execute("INSERT INTO evidence_claims (place_id,claim_type,value,source_type,source_ref,verbatim_span,verified_at,confidence,models_agree,doc_id,state) "
                         "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)", (*r, doc, state))
    return {"doc_id": str(doc), "verdict": verdict.verdict, "stored": len(rows), "agreed": sum(r[-1] for r in rows), "flags": sorted(flags)}
