"""Measured benchmark: constraint engine vs popularity ranker, checked by an INDEPENDENT re-implementation.
   python -m app.bench                                   engine metrics over ~1k generated scenarios
   python -m app.bench --extractor data/adapted.jsonl    + extractor agreement on Adaption-adapted rows (needs API keys)"""
import argparse, itertools, json
from datetime import datetime, timedelta, timezone

from .engine import BUFFER_MIN, IST, MINOR, Stop, eff, plan
from .guard import canon
from .world import load_world, pool


def violates(s: Stop, place, cs, now) -> bool:
    """Brute-force oracle: closure overlap, hours coverage, unpermitted sensitive site."""
    for c in cs:
        if c.ctype == "CLOSURE" and datetime.fromisoformat(c.value["from"]) <= s.arrive <= datetime.fromisoformat(c.value["until"]):
            return True
    if place.sensitive and not any(c.ctype == "ENTRY_RESTRICTION" and c.value.get("entry_allowed") is True for c in cs):
        return True
    a, d = s.arrive.astimezone(IST), s.depart.astimezone(IST)
    return not any(c.ctype == "OPERATING_HOURS" and eff(c, now) >= 0.5 and a.weekday() in c.value["days"]
                   and c.value["open"] <= a.strftime("%H:%M") and d.strftime("%H:%M") <= c.value["close"] and a.date() == d.date()
                   for c in cs)


def popularity(places, tt, day, start_hour, budget_h):   # Baseline B: landmarks first, hours ignored
    clock = datetime.combine(day, datetime.min.time(), IST).replace(hour=start_hour); end = clock + timedelta(hours=budget_h)
    pos, out = "hub", []
    for p in sorted((p for p in places if p.category != "essential_service"), key=lambda p: (p.category != "major_landmark", p.name)):
        a = clock + timedelta(minutes=tt[(pos, p.place_id)]); d = a + timedelta(minutes=p.visit_min)
        if d + timedelta(minutes=BUFFER_MIN + tt[(p.place_id, "hub")]) <= end:
            out.append(Stop(p.place_id, p.name, p.category, p.lat, p.lng, a, d, 0, {}, [], 0, "", "")); clock, pos = d + timedelta(minutes=BUFFER_MIN), p.place_id
    return out


def run_engine():
    now = datetime.now(timezone.utc); today = now.astimezone(IST).date()
    with pool.connection() as conn:
        places, claims, tt = load_world(conn)
    pl = {p.place_id: p for p in places}; ids = {c.claim_id for cs in claims.values() for c in cs}
    tally = {k: dict(plans=0, bad_plans=0, stops=0, leaked=0, cited=0, minor=0) for k in ("engine", "baseline_b")}
    combos = itertools.product(("budget_solo", "family_mid", "senior_accessible"), range(3, 9), (7, 9, 11), range(7),
                               ({"craft_artisan"}, {"minor_heritage"}, {"craft_artisan", "minor_heritage"}))
    for persona, bh, sh, dd, ints in combos:
        day = today + timedelta(days=dd)
        eng = plan(places, claims, tt, day, sh, bh, persona, ints, now).stops
        for name, stops in (("engine", eng), ("baseline_b", popularity(places, tt, day, sh, bh))):
            t = tally[name]; bad = [s for s in stops if violates(s, pl[s.place_id], claims.get(s.place_id, []), now)]
            t["plans"] += 1; t["bad_plans"] += bool(bad) or not stops; t["stops"] += len(stops); t["leaked"] += len(bad)
            t["cited"] += sum(bool(s.cites) and all(c in ids for c in s.cites) for s in stops); t["minor"] += any(s.category in MINOR for s in stops)
    for name, t in tally.items():
        print(f'{name:11} feasible={1 - t["bad_plans"] / t["plans"]:6.1%}  leakage={t["leaked"] / max(1, t["stops"]):6.1%}  '
              f'provenance={t["cited"] / max(1, t["stops"]):6.1%}  minor-exposure={t["minor"] / t["plans"]:6.1%}  (n={t["plans"]})')


def run_extractor(path: str, n: int):
    from . import llm
    hit = tot = pred = 0
    for line in itertools.islice(open(path, encoding="utf-8"), n):
        row = json.loads(line); gold = {(c["claim_type"], json.dumps(c["value"], sort_keys=True)) for c in json.loads(row["completion"])}
        out, _ = llm.dual_extract(row["prompt"])
        got = {(c.claim_type, json.dumps(v, sort_keys=True)) for c, ag in out if ag
               for v in [{"OPERATING_HOURS": {"days": c.days, "open": c.open, "close": c.close}, "CLOSURE": {"from": c.date_from, "until": c.date_until},
                          "ENTRY_RESTRICTION": {"entry_allowed": c.entry_allowed}}.get(c.claim_type)]}
        hit += len(gold & got); tot += len(gold); pred += len(got)
    p, r = hit / max(1, pred), hit / max(1, tot)
    print(f"extractor (dual-model agreed claims): precision={p:.1%} recall={r:.1%} f1={2 * p * r / max(1e-9, p + r):.1%}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--extractor"); ap.add_argument("--n", type=int, default=50); a = ap.parse_args()
    pool.open(wait=True); run_engine()
    if a.extractor:
        run_extractor(a.extractor, a.n)
