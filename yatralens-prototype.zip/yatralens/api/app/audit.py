"""Keyed hash chain over decisions. mac_n = HMAC(key, mac_{n-1} || canonical_json(row)); key lives in the C++ Keyring."""
import hashlib, json


GENESIS = "00" * 32


def payload(sid, inputs: dict, excluded: dict, models: dict, sha_hex: str) -> bytes:
    return json.dumps({"s": str(sid), "i": inputs, "x": excluded, "m": models, "r": sha_hex},
                      sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()   # ints/strings only: stable round-trip


def append(conn, keyring, sid, inputs, excluded, models, note: str) -> None:
    from psycopg.types.json import Jsonb   # lazy: demo build has no psycopg
    sha = hashlib.sha256(note.encode()).digest()
    with conn.transaction():
        conn.execute("SELECT pg_advisory_xact_lock(7461)")            # serialise chain heads
        row = conn.execute("SELECT mac FROM audit_log ORDER BY seq DESC LIMIT 1").fetchone()
        prev = bytes(row["mac"]).hex() if row else GENESIS
        mac = keyring.chain(prev, payload(sid, inputs, excluded, models, sha.hex()))
        conn.execute("INSERT INTO audit_log (session_id,inputs,excluded,models,rationale_sha256,prev_mac,mac) "
                     "VALUES (%s,%s,%s,%s,%s,%s,%s)",
                     (sid, Jsonb(inputs), Jsonb(excluded), Jsonb(models), sha, bytes.fromhex(prev), bytes.fromhex(mac)))


def verify(conn, keyring) -> tuple[bool, int]:
    prev, n = GENESIS, 0
    for r in conn.execute("SELECT * FROM audit_log ORDER BY seq"):
        want = keyring.chain(prev, payload(r["session_id"], r["inputs"], r["excluded"], r["models"], bytes(r["rationale_sha256"]).hex()))
        if bytes(r["prev_mac"]).hex() != prev or bytes(r["mac"]).hex() != want:
            return False, r["seq"]
        prev, n = want, n + 1
    return True, n
