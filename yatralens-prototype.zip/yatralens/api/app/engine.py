"""Deterministic core. No I/O, no LLM.   V = C_gate * clamp(sum_i w_i*S_i + bonus - 20*(1 - conf))"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")
HALF_LIFE_D = {"OFFICIAL_GOVT": 180, "OPERATOR_DIRECT": 90, "OSM_OVERPASS": 90, "VERIFIED_USER_OBSERVATION": 30}
MIN_EFF = 0.50          # positive evidence below this effective confidence is unusable
BUFFER_MIN = 10
EXPOSURE_BONUS = 8.0    # equalizer for verified minor sites that match the traveller's interests
MINOR = {"craft_artisan", "minor_heritage", "local_eatery"}
WEIGHTS = {             # configurable design choices, each row sums to 1
    "budget_solo":       {"health": .15, "food": .30, "transport": .25, "culture": .30},
    "family_mid":        {"health": .30, "food": .20, "transport": .20, "culture": .30},
    "senior_accessible": {"health": .40, "food": .10, "transport": .20, "culture": .30}}
LIMIT_M = {"health": 3000, "food": 800, "transport": 1000}


@dataclass(frozen=True)
class Claim:
    claim_id: str; place_id: str; ctype: str; value: dict
    source_type: str; source_ref: str; verified_at: datetime; confidence: float


@dataclass(frozen=True)
class Place:
    place_id: str; name: str; category: str; lat: float; lng: float; visit_min: int; sensitive: bool
    d_pharm: int | None; d_pharm_late: int | None; d_food: int | None; d_auto: int | None


@dataclass
class Gate:
    ok: bool; codes: list[str]; cites: list[str]; conf: float = 0.0; hours: Claim | None = None


@dataclass
class Stop:
    place_id: str; name: str; category: str; lat: float; lng: float
    arrive: datetime; depart: datetime; v: float; sub: dict; cites: list[str]; conf: float; open: str; close: str


@dataclass
class Plan:
    stops: list[Stop]; excluded: dict[str, dict]; total_min: int; limited: bool
    risks: list[str] = field(default_factory=list)
    names: dict[str, str] = field(default_factory=dict)


def eff(c: Claim, now: datetime) -> float:
    return c.confidence * 0.5 ** (max(0.0, (now - c.verified_at).total_seconds() / 86400) / HALF_LIFE_D[c.source_type])


def hours_ok(c: Claim, arrive: datetime, visit_min: int) -> bool:
    arrive = arrive.astimezone(IST)
    end = arrive + timedelta(minutes=visit_min)
    v = c.value
    return (arrive.weekday() in v["days"] and end.date() == arrive.date()
            and time.fromisoformat(v["open"]) <= arrive.time() and end.time() <= time.fromisoformat(v["close"]))


def gate(p: Place, cs: list[Claim], arrive: datetime, now: datetime) -> Gate:
    """C_gate. Negative evidence (closures, entry bans) never decays; positive evidence (hours, permits) does."""
    codes: list[str] = []; cites: list[str] = []; ended: list[datetime] = []
    for c in cs:
        if c.ctype != "CLOSURE":
            continue
        a, b = datetime.fromisoformat(c.value["from"]), datetime.fromisoformat(c.value["until"])
        if a <= arrive <= b:
            codes.append("CLOSURE_NOTICE_ACTIVE"); cites.append(c.claim_id)
        elif b < arrive:
            ended.append(b)          # closure is over: hours must be re-verified AFTER it ended
    since = max(ended, default=None)
    hrs = [c for c in cs if c.ctype == "OPERATING_HOURS" and eff(c, now) >= MIN_EFF and (since is None or c.verified_at > since)]
    ok_h = [c for c in hrs if hours_ok(c, arrive, p.visit_min)]
    if not hrs:
        codes.append("NO_VERIFIED_HOURS")
    elif not ok_h:
        codes.append("CLOSED_AT_ARRIVAL"); cites += [c.claim_id for c in hrs]
    ent = [c for c in cs if c.ctype == "ENTRY_RESTRICTION" and c.source_type == "OFFICIAL_GOVT"]
    if any(c.value.get("entry_allowed") is False for c in ent):
        codes.append("ENTRY_RESTRICTED"); cites += [c.claim_id for c in ent]
    elif p.sensitive and not any(c.value.get("entry_allowed") is True and eff(c, now) >= MIN_EFF for c in ent):
        codes.append("SENSITIVE_NO_OFFICIAL_PERMIT")
    best = max(ok_h, key=lambda c: eff(c, now), default=None)
    if not codes and best:
        cites = [best.claim_id]
    return Gate(not codes, codes, cites, eff(best, now) if best else 0.0, best)


def _s(d: int | None, lim: int) -> float:
    return 0.0 if d is None else max(0.0, 100.0 * (1 - d / lim))


def sub_scores(p: Place, interests: set[str]) -> dict:
    return {"health": (_s(p.d_pharm, LIMIT_M["health"]) + _s(p.d_pharm_late, LIMIT_M["health"])) / 2,
            "food": _s(p.d_food, LIMIT_M["food"]), "transport": _s(p.d_auto, LIMIT_M["transport"]),
            "culture": 100.0 if p.category in interests else 40.0}


def v_score(p: Place, g: Gate, persona: str, interests: set[str]) -> tuple[float, dict]:
    s, w = sub_scores(p, interests), WEIGHTS[persona]
    bonus = EXPOSURE_BONUS if p.category in MINOR and p.category in interests else 0.0
    v = sum(w[k] * s[k] for k in w) + bonus - 20.0 * (1 - g.conf)
    return round(max(0.0, min(100.0, v)), 1), {k: round(x) for k, x in s.items()}


def plan(places: list[Place], claims: dict[str, list[Claim]], tt: dict[tuple[str, str], int], day: date,
         start_hour: int, budget_h: int, persona: str, interests: set[str], now: datetime) -> Plan:
    clock = datetime.combine(day, time(start_hour), IST)
    start, end, pos = clock, clock + timedelta(hours=budget_h), "hub"
    left = {p.place_id: p for p in places if p.category != "essential_service"
            and (p.category in interests or p.category == "major_landmark")}
    stops: list[Stop] = []; verdict: dict[str, tuple[list[str], list[str]]] = {}
    while left:
        best = None
        for p in left.values():
            t_in, t_out = tt.get((pos, p.place_id)), tt.get((p.place_id, "hub"))
            if t_in is None or t_out is None:
                verdict[p.place_id] = (["NO_ROUTE_DATA"], []); continue
            arrive = clock + timedelta(minutes=t_in)
            g = gate(p, claims.get(p.place_id, []), arrive, now)
            if not g.ok:
                verdict[p.place_id] = (g.codes, g.cites); continue
            depart = arrive + timedelta(minutes=p.visit_min)
            if depart + timedelta(minutes=BUFFER_MIN + t_out) > end:
                verdict[p.place_id] = (["OVER_TIME_BUDGET"], g.cites); continue
            v, s = v_score(p, g, persona, interests)
            if best is None or (v, -t_in) > best[:2]:
                best = (v, -t_in, p, g, arrive, depart, s)
        if best is None:
            break
        v, _, p, g, arrive, depart, s = best
        h = g.hours.value  # type: ignore[union-attr]
        stops.append(Stop(p.place_id, p.name, p.category, p.lat, p.lng, arrive, depart, v, s, g.cites, round(g.conf, 2), h["open"], h["close"]))
        clock, pos = depart + timedelta(minutes=BUFFER_MIN), p.place_id
        del left[p.place_id]; verdict.pop(p.place_id, None)
    total = int(((clock - start).total_seconds() / 60) + (tt.get((pos, "hub"), 0) if stops else 0))
    risks = [f"nearest pharmacy to {s.name} is farther than 1500 m" for s in stops
             if persona == "senior_accessible" and (next(p for p in places if p.place_id == s.place_id).d_pharm or 99999) > 1500]
    return Plan(stops, {k: {"codes": c, "cites": ci} for k, (c, ci) in verdict.items() if k in left}, total,
                any(s.conf < 0.7 for s in stops), risks)
