"""Zero-dependency demo world: same fixtures as db/002_seed_demo.sql, held in memory. Used when YL_DATABASE_URL is unset.
Every claim is a DEMO-FIXTURE stand-in, exactly like the SQL seed."""
import math, threading
from datetime import datetime, timedelta, timezone

from . import audit
from .engine import IST, Claim, Place

_PL = [  # id, name, category, lng, lat, visit_min, sensitive
    ("hub", "Gwalior Junction (start / end)", "essential_service", 78.1827, 26.2152, 0, False),
    ("gwl_fort", "Gwalior Fort", "major_landmark", 78.1690, 26.2300, 120, False),
    ("tansen_tomb", "Tansen's Tomb", "minor_heritage", 78.1830, 26.2290, 45, False),
    ("gopachal_jain", "Gopachal Jain rock-cut sculptures", "minor_heritage", 78.1650, 26.2160, 40, True),
    ("gujari_mahal", "Gujari Mahal museum", "minor_heritage", 78.1695, 26.2310, 60, False),
    ("craft_demo", "Stone-carving workshop (demo)", "craft_artisan", 78.1500, 26.2180, 60, False)]
_SV = [("PHARMACY", 78.1700, 26.2250, False), ("PHARMACY", 78.1810, 26.2180, True), ("PHARMACY", 78.1520, 26.2200, False),
       ("BUDGET_FOOD", 78.1705, 26.2290, False), ("BUDGET_FOOD", 78.1825, 26.2160, True), ("BUDGET_FOOD", 78.1510, 26.2185, False),
       ("AUTO_STAND", 78.1830, 26.2150, True), ("AUTO_STAND", 78.1692, 26.2298, False)]


def _m(a, b) -> float:   # haversine, metres
    (x1, y1), (x2, y2) = a, b
    p1, p2, dl = math.radians(y1), math.radians(y2), math.radians(x2 - x1)
    h = math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * 6371008.8 * math.asin(math.sqrt(h))


def _near(pt, kind, late=False):
    d = [_m(pt, (x, y)) for k, x, y, l in _SV if k == kind and (not late or l)]
    return round(min(d)) if d else None


def _iso(d: datetime) -> str:
    return d.astimezone(IST).strftime("%Y-%m-%dT%H:%M:%S+05:30")


def load_world(now: datetime | None = None):
    now = now or datetime.now(timezone.utc)
    places = [Place(i, n, c, la, lo, v, s, _near((lo, la), "PHARMACY"), _near((lo, la), "PHARMACY", True),
                    _near((lo, la), "BUDGET_FOOD"), _near((lo, la), "AUTO_STAND")) for i, n, c, lo, la, v, s in _PL]
    xy = {i: (lo, la) for i, _, _, lo, la, _, _ in _PL}
    tt = {(a, b): max(5, math.ceil(_m(xy[a], xy[b]) * 1.4 / (18000 / 60))) for a in xy for b in xy if a != b}
    ago = lambda d: now - timedelta(days=d)
    allw, six = [0, 1, 2, 3, 4, 5, 6], [0, 1, 2, 3, 4, 5]
    rows = [  # place, type, value, source, verified_at, confidence
        ("gwl_fort", "OPERATING_HOURS", {"days": allw, "open": "09:00", "close": "17:30"}, "OFFICIAL_GOVT", ago(30), .98),
        ("tansen_tomb", "OPERATING_HOURS", {"days": allw, "open": "06:00", "close": "18:00"}, "OSM_OVERPASS", ago(45), .80),
        ("craft_demo", "OPERATING_HOURS", {"days": six, "open": "10:00", "close": "18:00"}, "OPERATOR_DIRECT", ago(10), .85),
        ("gujari_mahal", "OPERATING_HOURS", {"days": [1, 2, 3, 4, 5, 6], "open": "10:00", "close": "17:00"}, "OFFICIAL_GOVT", ago(20), .95),
        ("gujari_mahal", "CLOSURE", {"from": _iso(ago(2)), "until": _iso(now + timedelta(days=25))}, "OFFICIAL_GOVT", ago(3), .95),
        # closure already over; the only hours claim predates its end -> stays blocked until hours are re-verified
        ("gopachal_jain", "CLOSURE", {"from": "2026-01-01T00:00:00+05:30", "until": "2026-05-31T23:59:00+05:30"}, "OFFICIAL_GOVT",
         datetime.fromisoformat("2026-04-20T10:00:00+05:30"), .95),
        ("gopachal_jain", "OPERATING_HOURS", {"days": allw, "open": "07:00", "close": "18:00"}, "OSM_OVERPASS",
         datetime.fromisoformat("2026-02-01T10:00:00+05:30"), .70)]
    claims: dict[str, list[Claim]] = {}
    for n, (pid, t, v, s, at, cf) in enumerate(rows, 1):
        claims.setdefault(pid, []).append(Claim(f"c_{n:010x}", pid, t, v, s, "DEMO-FIXTURE", at, cf))
    return places, claims, tt


class DemoAudit:
    """In-memory keyed chain with the same payload/verify code as the Postgres path."""
    def __init__(self):
        self.rows, self._mu = [], threading.Lock()

    def append(self, keyring, sid, inputs, excluded, models, note):
        import hashlib
        sha = hashlib.sha256(note.encode()).digest()
        with self._mu:
            prev = self.rows[-1]["mac"] if self.rows else audit.GENESIS
            mac = keyring.chain(prev, audit.payload(sid, inputs, excluded, models, sha.hex()))
            self.rows.append({"seq": len(self.rows) + 1, "session_id": str(sid), "inputs": inputs, "excluded": excluded,
                              "models": models, "sha": sha.hex(), "prev_mac": prev, "mac": mac})

    def verify(self, keyring):
        prev = audit.GENESIS
        for r in self.rows:
            want = keyring.chain(prev, audit.payload(r["session_id"], r["inputs"], r["excluded"], r["models"], r["sha"]))
            if r["prev_mac"] != prev or r["mac"] != want:
                return False, r["seq"]
            prev = want
        return True, len(self.rows)
