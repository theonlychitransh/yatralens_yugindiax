from .config import cfg
from .engine import Claim, Place

try:                                   # absent in the standalone demo build (no Postgres)
    from psycopg.rows import dict_row
    from psycopg_pool import ConnectionPool
    pool = ConnectionPool(cfg.database_url or "dbname=postgres", min_size=1, max_size=8, open=False,
                          kwargs={"row_factory": dict_row})
except ImportError:                    # pragma: no cover
    pool = None

_PLACES = """SELECT place_id, name, category, ST_Y(geog::geometry) AS lat, ST_X(geog::geometry) AS lng, visit_minutes, sensitive,
  nearest_service_m(place_id,'PHARMACY') AS d_pharm, nearest_service_m(place_id,'PHARMACY',true) AS d_pharm_late,
  nearest_service_m(place_id,'BUDGET_FOOD') AS d_food, nearest_service_m(place_id,'AUTO_STAND') AS d_auto FROM places"""
_CLAIMS = """SELECT claim_id, place_id, claim_type::text AS ctype, value, source_type::text, source_ref, verified_at, confidence
  FROM evidence_claims"""          # RLS shows the yl_api role ACCEPTED rows only


def load_world(conn):
    places = [Place(r["place_id"], r["name"], r["category"], r["lat"], r["lng"], r["visit_minutes"], r["sensitive"],
                    r["d_pharm"], r["d_pharm_late"], r["d_food"], r["d_auto"]) for r in conn.execute(_PLACES)]
    claims: dict[str, list[Claim]] = {}
    for r in conn.execute(_CLAIMS):
        claims.setdefault(r["place_id"], []).append(Claim(r["claim_id"], r["place_id"], r["ctype"], r["value"],
                                                          r["source_type"], r["source_ref"], r["verified_at"], float(r["confidence"])))
    tt = {(r["from_id"], r["to_id"]): r["minutes"] for r in conn.execute("SELECT from_id, to_id, minutes FROM travel_time")}
    return places, claims, tt
