"""Claude + Gemini agents. Models propose; deterministic code (engine.py, guard.py) disposes."""
import json
from concurrent.futures import ThreadPoolExecutor
from functools import cache
from typing import Literal

import anthropic
from google import genai
from google.genai import types
from pydantic import BaseModel, Field

from . import prompts as P
from .config import cfg
from .guard import canon, wrap_untrusted

AUTH = {"OFFICIAL_GOVT": 4, "OPERATOR_DIRECT": 3, "OSM_OVERPASS": 2, "VERIFIED_USER_OBSERVATION": 1}


class XClaim(BaseModel):
    claim_type: Literal["OPERATING_HOURS", "CLOSURE", "ENTRY_RESTRICTION", "TRANSPORT_FARE", "ACCESSIBILITY"]
    days: list[int] | None = None
    open: str | None = None
    close: str | None = None
    date_from: str | None = None
    date_until: str | None = None
    entry_allowed: bool | None = None
    fare_inr: int | None = None
    verbatim_span: str = Field(max_length=300)


class Extraction(BaseModel):
    claims: list[XClaim] = Field(max_length=12)
    flags: list[Literal["SUSPECT", "NO_YEAR", "LANG_MIXED"]] = []


class Verdict(BaseModel):
    verdict: Literal["allow", "quarantine", "block"]
    findings: list[str] = Field(max_length=6)


class Ruling(BaseModel):
    chosen_claim_id: str | None
    reason: Literal["NEWER_OFFICIAL", "HIGHER_AUTHORITY", "CONSENSUS", "IRRECONCILABLE"]
    needs_human: bool


@cache
def _gem() -> genai.Client:  # reads GEMINI_API_KEY
    return genai.Client(http_options=types.HttpOptions(timeout=int(cfg.llm_timeout_s * 1000)))


@cache
def _cl() -> anthropic.Anthropic:  # reads ANTHROPIC_API_KEY
    return anthropic.Anthropic(max_retries=1, timeout=cfg.llm_timeout_s)


def _claude_tool(model: str, system: str, user: str, name: str, schema: dict, max_tokens: int) -> dict:
    r = _cl().messages.create(
        model=model, max_tokens=max_tokens, system=system,
        tools=[{"name": name, "description": "Return the structured result.", "input_schema": schema}],
        tool_choice={"type": "tool", "name": name},   # forced tool call = schema-constrained output
        messages=[{"role": "user", "content": user}])
    return next(b.input for b in r.content if b.type == "tool_use")


# 1. Sentinel (Claude Haiku): screens untrusted text before any extractor sees it
def sentinel(doc: str) -> Verdict:
    return Verdict.model_validate(_claude_tool(cfg.claude_sentinel, P.SENTINEL, wrap_untrusted(doc), "classify",
                                               Verdict.model_json_schema(), 400))


# 2a. Extractor (Gemini): multilingual text -> typed claims.  Gemini 3 keeps default temperature (Google's guidance).
def extract_gemini(doc: str) -> Extraction:
    r = _gem().models.generate_content(
        model=cfg.gemini_model, contents=wrap_untrusted(doc),
        config=types.GenerateContentConfig(system_instruction=P.EXTRACTOR, response_mime_type="application/json",
                                           response_schema=Extraction))
    return Extraction.model_validate_json(r.text)


# 2b. Independent second extractor (Claude Sonnet), same prompt, different vendor
def extract_claude(doc: str) -> Extraction:
    return Extraction.model_validate(_claude_tool(cfg.claude_judge, P.EXTRACTOR, wrap_untrusted(doc), "extract",
                                                  Extraction.model_json_schema(), 1500))


def _key(c: XClaim) -> tuple:
    return (c.claim_type, tuple(c.days or ()), c.open, c.close, c.date_from, c.date_until, c.entry_allowed, c.fare_inr)


def dual_extract(doc: str) -> tuple[list[tuple[XClaim, bool]], set[str]]:
    """A claim is 'agreed' only if its span occurs verbatim in the source AND the other vendor produced the same value."""
    with ThreadPoolExecutor(2) as ex:
        fa, fb = ex.submit(extract_gemini, doc), ex.submit(extract_claude, doc)
        a, b = fa.result(), fb.result()
    src, kb = canon(doc), {_key(c) for c in b.claims}
    out = [(c, canon(c.verbatim_span) in src and _key(c) in kb) for c in a.claims]
    return out, set(a.flags) | set(b.flags)


# 3. Adjudicator (Claude Sonnet): picks among existing claims; code enforces the authority rules afterwards
def adjudicate(claims: list[dict]) -> Ruling:
    ids = {c["claim_id"] for c in claims}
    r = Ruling.model_validate(_claude_tool(cfg.claude_judge, P.ADJUDICATOR, json.dumps(claims, default=str),
                                           "rule", Ruling.model_json_schema(), 200))
    pick = next((c for c in claims if c["claim_id"] == r.chosen_claim_id), None)
    unsafe = r.chosen_claim_id is not None and pick is None
    if pick and pick["claim_type"] == "OPERATING_HOURS":   # never let a lower-authority 'open' beat an official closure
        unsafe |= any(c["claim_type"] in ("CLOSURE", "ENTRY_RESTRICTION") and AUTH[c["source_type"]] > AUTH[pick["source_type"]]
                      for c in claims if c["claim_id"] in ids)
    return Ruling(chosen_claim_id=None, reason="IRRECONCILABLE", needs_human=True) if unsafe else r


# 4. Explainer (Claude Sonnet): prose over engine output only; guard.validate_note checks it afterwards
def explain(facts: dict) -> str:
    r = _cl().messages.create(model=cfg.claude_judge, max_tokens=400, system=P.EXPLAINER,
                              messages=[{"role": "user", "content": json.dumps(facts, ensure_ascii=False)}])
    return r.content[0].text.strip()


# 5. Translator (Gemini): validated English note -> hi/mr/kn/ta/bn; guard.same_facts checks it afterwards
def translate(note: str, lang: str) -> str:
    r = _gem().models.generate_content(model=cfg.gemini_model, contents=f"TARGET: {lang}\n\n{note}",
                                       config=types.GenerateContentConfig(system_instruction=P.TRANSLATOR))
    return r.text.strip()
