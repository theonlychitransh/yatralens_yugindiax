# PyInstaller spec: python -m PyInstaller --noconfirm yatralens.spec   (run from api/, after `npm run build` in ../web)
import os
from PyInstaller.utils.hooks import collect_submodules
web = os.path.join("..", "web", "dist")
hidden = collect_submodules("uvicorn")
for m in ("anthropic", "google.genai"):          # optional: bundled only if installed
    try:
        hidden += collect_submodules(m)
    except Exception:
        pass
a = Analysis(["launcher.py"], pathex=["."], datas=[(web, "web")], hiddenimports=hidden, excludes=["tkinter"])
exe = EXE(PYZ(a.pure), a.scripts, a.binaries, a.datas, [], name="yatralens", console=True, upx=False)
